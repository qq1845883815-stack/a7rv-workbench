import AppKit
let image=NSImage(size:NSSize(width:1024,height:1024));image.lockFocus()
NSColor(calibratedRed:0.07,green:0.20,blue:0.23,alpha:1).setFill()
NSBezierPath(roundedRect:NSRect(x:32,y:32,width:960,height:960),xRadius:210,yRadius:210).fill()
NSColor(calibratedRed:0.24,green:0.48,blue:0.49,alpha:1).setStroke()
let rim=NSBezierPath(roundedRect:NSRect(x:118,y:118,width:788,height:788),xRadius:160,yRadius:160);rim.lineWidth=4;rim.stroke()
NSColor(calibratedRed:0.49,green:0.87,blue:0.80,alpha:1).setStroke()
let v=NSBezierPath();v.move(to:NSPoint(x:287,y:722));v.line(to:NSPoint(x:512,y:292));v.line(to:NSPoint(x:737,y:722));v.lineWidth=62;v.lineCapStyle = .round;v.lineJoinStyle = .round;v.stroke()
image.unlockFocus();let bitmap=NSBitmapImageRep(data:image.tiffRepresentation!)!;try bitmap.representation(using:.png,properties:[:])!.write(to:URL(fileURLWithPath:CommandLine.arguments[1]))
