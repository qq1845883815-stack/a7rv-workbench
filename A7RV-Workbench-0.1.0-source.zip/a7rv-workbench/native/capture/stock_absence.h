/* Stock-camera absence policy. Read metadata only; never create preload files.
 * Preserve parent identities across the capture/cleanup task. These checks
 * detect observed changes; they cannot exclude a change between syscalls.
 */
struct stock_stat {u64 dev,ino;unsigned mode,nlink,uid,gid;u64 rdev,pad;s64 size;unsigned blksize,pad2;u64 blocks,rest[7];};
_Static_assert(sizeof(struct stock_stat)==128,"AArch64 stat ABI");
static struct stock_stat stock_parents[3];
static unsigned stock_initialized;
static int stock_absence(void) {
    const char *parents[]={"/etc","/tmp","/tmp/jiritsu"};
    const char *files[]={"/etc/ld.so.preload","/tmp/ld.so.preload",
        "/tmp/jiritsu/../../etc/ld.so.preload","/tmp/jiritsu/../../tmp/ld.so.preload"};
    struct stock_stat now;
    for(unsigned pass=0;pass<2;pass++){
        for(unsigned i=0;i<3;i++){
            if(sc(79,AT_FDCWD,P(parents[i]),P(&now),256,0,0)!=0||
               (now.mode&0170000)!=0040000||now.uid!=0)return -1;
            if(stock_initialized||pass){
                if(now.dev!=stock_parents[i].dev||now.ino!=stock_parents[i].ino||
                   now.mode!=stock_parents[i].mode||now.uid!=stock_parents[i].uid||
                   now.gid!=stock_parents[i].gid)return -1;
            }else stock_parents[i]=now;
        }
        for(unsigned i=0;i<4;i++){
            if(sc(79,AT_FDCWD,P(files[i]),P(&now),256,0,0)!=-2||
               sc(79,AT_FDCWD,P(files[i]),P(&now),0,0,0)!=-2)return -1;
        }
    }
    stock_initialized=1;return 0;
}
