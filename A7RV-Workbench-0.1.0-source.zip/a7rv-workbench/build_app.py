from pathlib import Path
import shutil,subprocess,json,plistlib,hashlib,os
import argparse
parser=argparse.ArgumentParser(description='Build on macOS arm64; never accesses a camera')
parser.add_argument('--engine',required=True,type=Path,help='engine folder from the verified 0.1.0 release app')
parser.add_argument('--output',type=Path,default=Path('dist/A7R V 工坊.app'))
args=parser.parse_args();D=Path(__file__).resolve().parent;OUT=args.output.absolute();E=args.engine.resolve()
assert (E/'python/bin/python3.14').is_file() and (E/'bootstrap.py').is_file(), 'Missing release runtime'
assert not OUT.exists(), 'Output already exists; choose a new output path' 
CONT=OUT/'Contents';RES=CONT/'Resources';BIN=CONT/'MacOS';BIN.mkdir(parents=True);RES.mkdir()
shutil.copytree(E,RES/'engine',symlinks=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
shutil.copytree(D/'engine-source',RES/'engine',dirs_exist_ok=True)
# Root always verifies the same resource identities before device work.
APP=RES/'app';APP.mkdir()
for name in ['backend.py','stock_capture_operation.py','stock_trust_operation.template']:shutil.copyfile(D/'src'/name,APP/name)
shutil.copytree(D/'src/web',APP/'web');shutil.copytree(D/'build-assets',APP/'assets')
SOURCES=RES/'sources';SOURCES.mkdir();shutil.copytree(D/'src',SOURCES/'workbench',ignore=shutil.ignore_patterns('__pycache__'))
shutil.copytree(D/'native/trust',SOURCES/'native-trust');shutil.copytree(D/'native/capture',SOURCES/'native-capture')
for label in ['stock-v1','reference-v1']:shutil.copytree(D/'native'/label,SOURCES/('native-'+label))
shutil.copyfile(D/'LICENSE',RES/'LICENSE-REA.txt')
(RES/'README.txt').write_text('A7R V 工坊 0.1.0 · Mac Apple Silicon研究测试版\n\n仅适配ILCE-7RM5指定官方4.00、两种封存原像以及预加载文件缺失的原厂状态。stock-v1的前代固定会话在本机实测；新的通用应用和reference-v1未进行其他机身实测。不能据此保证所有4.00相机均适配。\n\n启动不访问相机。先检查连接、备份、匹配完整原像，再独立确认一次性信任事务。未知状态不重试、不追加退出服务。不提供强制模式、自动回滚或SSH。封包、卡复制与机内安装分离，卡刷需另行决定。\n\n离线封包使用上游公开研究签名私钥，非索尼身份，不含任何用户私钥或个人分区镜像。官方DAT、原厂SDK、照片、上次批准和任务记录不随应用分发。图形界面、后台、模板及可读源码均在本地。\n\n应用独立使用~/Library/Application Support/local.a7rv.workbench；不修改旧REA应用数据。新设备失败记录必须保留，没有“清除标记重试”按钮。每个设备动作需要确认和终端授权。\n\n基于https://github.com/Liwenru88/a7r5-rea，提交290c79e65fb52b5b64ac64a1c9a835a63d7d821f，Apache-2.0。相关第三方许可保留于engine/notices。未经Developer ID签名或公证，初次打开可能需要右键打开。当前只在本机Mac验证。\n')
info={'CFBundleName':'A7R V 工坊','CFBundleDisplayName':'A7R V 工坊','CFBundleIdentifier':'local.a7rv.workbench','CFBundleVersion':'1','CFBundleShortVersionString':'0.1.0','CFBundlePackageType':'APPL','CFBundleExecutable':'A7RVWorkbench','LSMinimumSystemVersion':'14.0','NSHighResolutionCapable':True,'NSPrincipalClass':'NSApplication'}
info['CFBundleIconFile']='Workbench'
shutil.copyfile(D/'Workbench.icns',RES/'Workbench.icns')
(CONT/'Info.plist').write_bytes(plistlib.dumps(info))
# Seal only regular files; existing runtime symlinks stay inside the signed runtime.
manifest={}
for p in sorted(RES.rglob('*')):
 if p.is_file()and not p.is_symlink():
  with p.open('rb')as f:manifest[str(p.relative_to(RES))]=hashlib.file_digest(f,'sha256').hexdigest()
(RES/'resources.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
seal=hashlib.sha256((RES/'resources.json').read_bytes()).hexdigest();swift=(D/'src/App.swift').read_text().replace('__RESOURCE_SEAL__',seal);(D/'App-bound.swift').write_text(swift)
p=subprocess.run(['/usr/bin/swiftc','-swift-version','5','-O','-target','arm64-apple-macos14.0','-framework','AppKit','-framework','WebKit',str(D/'App-bound.swift'),'-o',str(BIN/'A7RVWorkbench')],capture_output=True,text=True)
(D/'compile.log').write_text(p.stdout+p.stderr)
assert p.returncode==0,p.stderr
subprocess.run(['/usr/bin/codesign','--force','--sign','-',str(OUT)],check=True,capture_output=True)
subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(OUT)],check=True,capture_output=True)
(D/'app-build.json').write_text(json.dumps({'app':str(OUT),'resources_sha256':seal,'resources_files':len(manifest),'swift_compiled':True,'ad_hoc_signed':True,'notarized':False,'device_tested':False},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'app':str(OUT),'resources_sha256':seal,'files':len(manifest)},ensure_ascii=False))
