"""Erase nonallocated ELF debug sections only; assert every load segment is unchanged."""
from pathlib import Path
import struct,json,hashlib
D=Path(__file__).resolve().parent
for name in ('capture.so','cleanup.so'):
 p=D/'build-assets'/name;old=p.read_bytes();new=bytearray(old)
 assert old[:6]==b'\x7fELF\x02\x01'
 phoff=struct.unpack_from('<Q',old,32)[0];shoff=struct.unpack_from('<Q',old,40)[0]
 phsize,phnum,shsize,shnum,shstr=struct.unpack_from('<5H',old,54)
 sections=[struct.unpack_from('<IIQQQQIIQQ',old,shoff+i*shsize) for i in range(shnum)]
 names=sections[shstr];strings=old[names[4]:names[4]+names[5]]
 loads=[]
 for i in range(phnum):
  typ,flags,offset,vaddr,paddr,filesz,memsz,align=struct.unpack_from('<II6Q',old,phoff+i*phsize)
  if typ==1:loads.append((offset,offset+filesz))
 for s in sections:
  name_offset=s[0];label=strings[name_offset:strings.find(b'\0',name_offset)]
  if label.startswith(b'.debug'):
   assert not s[2]&2,'Allocated section must never be edited'
   start,end=s[4],s[4]+s[5]
   assert all(end<=a or start>=b for a,b in loads)
   new[start:end]=b'\0'*(end-start)
 for a,b in loads:assert new[a:b]==old[a:b]
 assert b'/Users/' not in new
 p.write_bytes(new)
manifest={}
for p in (D/'build-assets').glob('*.so'):
 raw=p.read_bytes();manifest[p.name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'run_fields':raw.count(b'0'*32)}
(D/'build-assets/payloads.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Nonallocated debug data cleared; all PT_LOAD bytes preserved')
