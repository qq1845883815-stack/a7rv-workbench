"""A7R V 工坊：显式动作、离线封包与严格首装事务。导入不查询USB。"""
from pathlib import Path
import base64,datetime,fcntl,hashlib,importlib.util,json,os,plistlib,re,shutil,stat,subprocess,sys,time,types,uuid
ROOT=Path(__file__).resolve().parent;ENGINE=ROOT.parent/'engine';ASSETS=ROOT/'assets'
DATA=Path.home()/'Library/Application Support/local.a7rv.workbench'
SIZE=25100288;MARKER='0'*32
OFFICIAL='51e1176a255a9a4b4782dfbcfa6c5f332b71173bdfe9ed2bcf4fca6bcbc6c2e2'
sys.path[:0]=[str(ROOT),str(ENGINE),str(ENGINE/'site')]

def regular(p):
 p=Path(p).absolute()
 if '..'in p.parts or p.is_relative_to('/dev')or any(x.is_symlink()for x in (p,*p.parents)):raise ValueError('请选择普通文件，不能使用链接或设备路径')
 if not stat.S_ISREG(p.stat().st_mode):raise ValueError('不是普通文件')
 return p

def sha(p):
 with regular(p).open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()

def load(p):return json.loads(regular(p).read_text())
def save(p,v):
 raw=(json.dumps(v,ensure_ascii=False,indent=2)+'\n').encode();fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with os.fdopen(fd,'wb')as f:f.write(raw);f.flush();os.fsync(f.fileno())

def note(text):print(json.dumps({'progress':text},ensure_ascii=False),flush=True)
def run_id(value):
 if not isinstance(value,str)or not re.fullmatch('[a-f0-9]{32}',value):raise ValueError('任务编号无效')
 return value

def profiles():return {label:load(ASSETS/(label+'.json'))for label in ('stock-v1','reference-v1')}

def identify_backup(path):
 p=regular(path)
 if p.stat().st_size!=SIZE:raise ValueError('一号分区备份必须完整，共25100288字节')
 digest=sha(p)
 for name,v in profiles().items():
  if digest==v['source_sha256']:return dict(state='supported-original',profile=name,sha256=digest,bytes=SIZE,live_verified_layout=name=='stock-v1')
  if digest==v['target_sha256']:return dict(state='already-trusted',profile=name,sha256=digest,bytes=SIZE,live_verified_layout=name=='stock-v1')
 return dict(state='unsupported',profile=None,sha256=digest,bytes=SIZE,write_allowed=False)

def candidate_bytes(raw,profile):
 v=profiles()[profile]
 if len(raw)!=SIZE or hashlib.sha256(raw).hexdigest()!=v['source_sha256']:raise ValueError('完整原像不匹配，不生成写入方案')
 new=bytearray(raw);offsets=[]
 for row in v['rows']:
  at=row['offset'];a=base64.b64decode(row['before'],validate=True);b=base64.b64decode(row['after'],validate=True)
  if len(a)!=512 or len(b)!=512 or at%512 or raw[at:at+512]!=a or at in offsets:raise ValueError('扇区前像不匹配')
  new[at:at+512]=b;offsets.append(at)
 if len(offsets)!=258 or hashlib.sha256(new).hexdigest()!=v['target_sha256']:raise ValueError('候选完整摘要不匹配')
 changed={i for i in range(0,SIZE,512)if raw[i:i+512]!=new[i:i+512]}
 if changed!=set(offsets):raise ValueError('修改范围超出封存方案')
 return bytes(new),v['plan']

def render(name,run):
 run_id(run);record=load(ASSETS/'payloads.json')[name];p=ASSETS/name;raw=p.read_bytes()
 if sha(p)!=record['sha256']or len(raw)!=record['bytes']or raw.count(MARKER.encode())!=record['run_fields']:raise ValueError('机内模板身份变化')
 return raw.replace(MARKER.encode(),run.encode())

def ensure_data():
 DATA.mkdir(mode=0o700,parents=True,exist_ok=True)
 if DATA.is_symlink()or DATA.stat().st_uid!=os.getuid()or DATA.stat().st_mode&0o077:raise ValueError('应用数据目录权限异常')
 (DATA/'jobs').mkdir(mode=0o700,exist_ok=True);(DATA/'requests').mkdir(mode=0o700,exist_ok=True)

def overview():
 ensure_data();jobs=[]
 for p in sorted((DATA/'jobs').iterdir(),key=lambda p:p.stat().st_mtime,reverse=True)[:40]:
  if p.is_dir()and not p.is_symlink():
   row={'id':p.name,'directory':str(p)}
   for name in ['request.json','result.json','device-result.json','screen-confirmation.json','terminal-result.json']:
    if(p/name).is_file():
     try:row[name]=load(p/name)
     except Exception:pass
   jobs.append(row)
 return {'jobs':jobs,'data_directory':str(DATA),'version':'0.1.0','supported':'ILCE-7RM5 / 指定官方4.00 / 两种已识别原像','camera_queried':False}

def snapshot(job,label,timeout=5):
 import host
 raw=subprocess.run(['/usr/sbin/ioreg','-a','-l','-r','-c','IOUSBHostDevice'],capture_output=True,check=True,timeout=timeout).stdout
 (job/(label+'.plist')).write_bytes(raw)
 return host.parse(plistlib.loads(raw)if raw.strip()else[])

def baseline(job):
 import host
 first=snapshot(job,'host-initial')
 if first.get('kind')!='ordinary':raise ValueError('请连接唯一一台A7R V，并选择USB海量存储')
 proof=host.observe(first,lambda label,timeout=5:snapshot(job,label,timeout),seconds=8)
 save(job/'host-proof.json',proof)
 if not proof['recovered']:raise ValueError('USB媒体或驱动尚未稳定')
 return first

def setup_package(job,kind,backup=None):
 from common import config
 run=job.name;base=baseline(job);cfg=config(run,base);cfg.update(observe_seconds=90,preload_policy='stock-absent-v1')
 package=job/'package';(package/'materials').mkdir(parents=True,mode=0o700)
 def put(name,raw):(package/'materials'/name).write_bytes(raw)
 put('ticket.bin',('A7R5_LIBJIT '+run+'\n').encode())
 if kind=='capture':
  cfg.update(metadata_policy='native-raw-absence-v1',capture_format='ram-16k-v1',capture_control_layout='ram-v2',capture_cleanup_policy='verified-current-ram-v2',capture_path='/tmp_wbshd/a7r5-capture-'+run+'/partition.bin',expected_output_begin='A7R5_CAPTURE_BEGIN '+run+'\n',expected_output_end='A7R5_CAPTURE_END '+run+'\n')
  put('libJit.so',render('capture.so',run));put('capture-cleanup.so',render('cleanup.so',run))
 else:
  info=identify_backup(backup)
  if info['state']!='supported-original':raise ValueError('这份备份不需要写入或尚未适配，已停止')
  raw=regular(backup).read_bytes();new,plan=candidate_bytes(raw,info['profile']);ram='/tmp_wbshd/a7r5-trust-'+run
  put('source.logical.img',raw);put('candidate.logical.img',new);put('write-plan.json',(json.dumps(plan,indent=2)+'\n').encode());put('libJit.so',render(info['profile']+'.so',run))
  cfg.update(source_sha256=hashlib.sha256(raw).hexdigest(),candidate_sha256=hashlib.sha256(new).hexdigest(),force_install=False,trust_control_layout='ram-v2',trust_readback_format='stock-full-16k-v1',trust_resource_policy='strict-64m-v1',journal_path=ram+'/journal',readback_path=ram+'/partition.logical',expected_output_begin='A7R5_TRUST_BEGIN_'+run+'\n',expected_output_end='A7R5_TRUST_END_'+run+'\n')
  save(job/'backup-compatibility.json',info)
 save(package/'config.json',cfg)
 seal={str(p.relative_to(package)):sha(p)for p in package.rglob('*')if p.is_file()};save(job/'package-seal.json',seal)
 return cfg

def operation(package,kind):
 if kind=='capture':
  from stock_capture_operation import Operation
 else:
  cfg=load(package/'config.json');p=package/'materials/write-plan.json'
  source=(ROOT/'stock_trust_operation.template').read_text()
  for old,new in [('ba3933451591b4f6a63d5fea81c86c732f296cec3f2e40a6b912daf96b359c12',cfg['source_sha256']),('4c8b04f6b845bf69745e0abedda74fc08e14e705683897b0738344cf680a4ad9',cfg['candidate_sha256']),('57dbd54804f27772253b7bd2dd05ca53e0eec5e0b11b8f90f91af49c3c3d7457',sha(p))]:
   if not re.fullmatch('[0-9a-f]{64}',new):raise ValueError('摘要格式异常')
   source=source.replace(old,new)
  module=types.ModuleType('bound_stock_trust');exec(compile(source,'<sealed-bound-stock-trust>','exec'),module.__dict__);Operation=module.Operation
 return Operation(package)

def prepare_device(job,kind,request):
 for previous in (DATA/'jobs').iterdir():
  if previous!=job and(previous/'device.attempt').exists():
   if not(previous/'device-result.json').is_file()or not load(previous/'device-result.json').get('complete'):
    raise ValueError('上一设备任务结果尚未完整核验，禁止新事务。保留现场：'+previous.name)
 cfg=setup_package(job,kind,request.get('backup'))
 approval={'id':job.name,'kind':kind,'scope':'one_capture_verified_ram_cleanup'if kind=='capture'else'one_trust_258_sectors_full_readback_no_install','package_seal_sha256':sha(job/'package-seal.json'),'explicit_native_confirmation':True,'created_at':time.time(),'automatic_retry':False,'automatic_rollback':False}
 save(job/'approval.json',approval)
 return {'state':'awaiting-terminal','kind':kind,'job':str(job),'id':job.name,'approval':approval,'display':'终端将请求Mac登录密码，密码不进入应用。'}

def validate_device_materials(package,kind):
 cfg=load(package/'config.json');run=run_id(cfg['run_id']);m=package/'materials'
 if(m/'ticket.bin').read_bytes()!=('A7R5_LIBJIT '+run+'\n').encode():raise ValueError('票据不符')
 from common import config
 original=config(run,cfg['host_baseline'])
 for key in ['version_sha256','loader_sha256','loader_bytes','interfaces']:
  if cfg[key]!=original[key]:raise ValueError('设备绑定格式变化')
 if kind=='capture':
  if(m/'libJit.so').read_bytes()!=render('capture.so',run)or(m/'capture-cleanup.so').read_bytes()!=render('cleanup.so',run):raise ValueError('采集模板变化')
  if cfg['metadata_policy']!='native-raw-absence-v1' or cfg['capture_path']!='/tmp_wbshd/a7r5-capture-'+run+'/partition.bin':raise ValueError('采集策略变化')
 else:
  info=identify_backup(m/'source.logical.img')
  if info['state']!='supported-original':raise ValueError('未知完整原像')
  new,plan=candidate_bytes((m/'source.logical.img').read_bytes(),info['profile'])
  if(m/'candidate.logical.img').read_bytes()!=new or load(m/'write-plan.json')!=plan or(m/'libJit.so').read_bytes()!=render(info['profile']+'.so',run):raise ValueError('写入候选或模板变化')
  if cfg.get('force_install')is not False:raise ValueError('禁止强制覆盖')
 return True

def execute_device(jobid):
 run_id(jobid)
 if os.geteuid()!=0 or not os.environ.get('SUDO_UID','').isdigit():raise ValueError('必须通过本次终端管理员授权')
 uid=int(os.environ['SUDO_UID']);gid=int(os.environ['SUDO_GID']);home=Path(__import__('pwd').getpwuid(uid).pw_dir)
 global DATA;DATA=home/'Library/Application Support/local.a7rv.workbench'
 job=DATA/'jobs'/jobid
 if job.is_symlink()or job.stat().st_uid!=uid or job.stat().st_mode&0o077:raise ValueError('任务身份异常')
 approval=load(job/'approval.json');kind=approval['kind']
 if time.time()-approval.get('created_at',0)>120:raise ValueError('终端授权等待超过120秒，未访问相机；请新建任务')
 if kind not in ('capture','trust')or approval['id']!=jobid or approval.get('explicit_native_confirmation')is not True or approval['package_seal_sha256']!=sha(job/'package-seal.json'):raise ValueError('本次确认不匹配')
 package=job/'package'
 for rel,digest in load(job/'package-seal.json').items():
  if Path(rel).is_absolute()or '..'in Path(rel).parts or sha(package/rel)!=digest:raise ValueError('任务材料变化')
 cfg=load(package/'config.json')
 if cfg['run_id']!=jobid:raise ValueError('会话不匹配')
 validate_device_materials(package,kind)
 # Root-owned cross-application lock; marker is permanent once authentication may begin.
 fd=os.open('/private/tmp/local.a7r5.studio.device.lock',os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW,0o600)
 if os.fstat(fd).st_uid!=0:os.close(fd);raise ValueError('设备锁所有者异常')
 fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 marker=job/'device.attempt';op=None;report={};after=None;failure=None
 try:
  if marker.exists()or(job/'device-result.json').exists()or(job/'terminal-result.json').exists():raise FileExistsError('本次机会已消耗，不能重试；请查看原记录')
  if shutil.disk_usage(job).free<512*1024*1024:raise ValueError('电脑至少需要512MiB可用空间')
  if subprocess.run(['/usr/bin/pgrep','-x','a7r5-desktop'],capture_output=True).returncode!=1:raise ValueError('请先退出旧版A7R5客户端')
  import host
  proof=host.observe(cfg['host_baseline'],lambda label,timeout=5:snapshot(job,'execute-'+label,timeout),seconds=8)
  if not proof['recovered']:raise ValueError('本次相机身份或端口变化；未认证')
  op=operation(package,kind);op.output=job/'device'
  save(marker,{'id':jobid,'automatic_retry':False,'scope':approval['scope']})
  from system_dump import session
  report=session.run_session(op.output,'libusb',_operation=op)
  if op.safe_to_stop:after=host.observe(cfg['host_baseline'],lambda label,timeout=5:snapshot(job,'after-'+label,timeout),seconds=40)
 except BaseException as exc:failure=type(exc).__name__+': '+str(exc)
 finally:
  result={'kind':kind,'id':jobid,'report':report,'failure':failure,'MSC_recovered':bool(after and after['recovered']),'screen_confirmation_required':True,'complete':bool(op and op.safe_to_stop and after and after['recovered']and not failure and not report.get('failure')),'automatic_retry':False,'automatic_rollback':False,'attempt_consumed':marker.exists()}
  try:
   save(job/'device-result.json',result)
   for p in job.rglob('*'):
    if p.is_symlink():raise ValueError('证据包含异常链接')
    os.chown(p,uid,gid,follow_symlinks=False)
   os.chown(job,uid,gid)
  finally:os.close(fd)
 print(json.dumps(result,ensure_ascii=False),flush=True)
 return 0 if result['complete']else 1

def dispatch(action,request,job):
 if action=='overview':return overview()
 if action=='scan':return {'baseline':baseline(job),'camera_IO':'host_metadata_only'}
 if action=='inspect_firmware':
  from a7r5dat import tool
  p=regular(request['source'])
  if p.stat().st_size!=754525608 or sha(p)!=OFFICIAL:raise ValueError('原包不匹配，仅支持指定官方4.00')
  return tool.inspect(p,ENGINE/'keys/sony-original-public.pem',full=False)
 if action=='inspect_backup':return identify_backup(request['backup'])
 if action=='card_volumes':return {'volumes':card_volumes()}
 if action=='copy_card':
  if request.get('native_confirmed')is not True:raise ValueError('缺少写卡确认')
  return copy_card(request,job)
 if action=='firmware':
  import firmware
  flags=request['features']
  output=Path(request['output']).absolute()
  # Fixed official workspace uses <1GiB; retain the DAT tool's 2GiB unpack / 3GiB pack checks.
  if shutil.disk_usage(output.parent).free<=4<<30:raise ValueError('封包前需要超过4GiB可用空间，建议5GiB；每阶段仍单独检查')
  if set(flags)!=set(firmware.KEYS)or any(type(v)is not bool for v in flags.values()):raise ValueError('请选择功能')
  buildroot=job/'firmware';buildroot.mkdir(mode=0o700)
  value=firmware.build(request,buildroot)
  guide=Path(value['guide'])
  text=guide.read_text();needle='</head>'if '</head>'in text else '</style>'
  text=text.replace(needle,needle+'<style>*{font-family:SimSun,\"宋体\",serif!important}</style>',1)
  guide.write_text(text)
  return value
 if action in ('prepare_capture','prepare_trust'):
  if request.get('native_confirmed')is not True:raise ValueError('缺少本次机内操作确认')
  return prepare_device(job,'capture'if action=='prepare_capture'else'trust',request)
 if action=='confirm_screen':
  target=DATA/'jobs'/run_id(request['job_id']);v=load(target/'device-result.json')
  if not v['complete']:raise ValueError('设备记录未完成，不能标记屏幕正常')
  save(target/'screen-confirmation.json',{'user_confirmed_MSC':True});return {'screen_confirmed':True}
 raise ValueError('不支持的操作')

def card_volumes():
 tree=plistlib.loads(subprocess.run(['/usr/sbin/diskutil','list','-plist','external','physical'],capture_output=True,check=True,timeout=20).stdout);rows=[]
 for disk in tree.get('AllDisksAndPartitions',[]):
  for part in disk.get('Partitions',[]):
   if not part.get('MountPoint'):continue
   info=plistlib.loads(subprocess.run(['/usr/sbin/diskutil','info','-plist',part['DeviceIdentifier']],capture_output=True,check=True,timeout=20).stdout)
   if info.get('FilesystemType')not in('exfat','msdos')or not info.get('WritableVolume')or info.get('Internal')or info.get('FreeSpace',0)<1<<30:continue
   rows.append({'device':info['DeviceIdentifier'],'whole_disk':info['ParentWholeDisk'],'mount':info['MountPoint'],'name':info['VolumeName'],'uuid':info['VolumeUUID'],'free_bytes':info['FreeSpace'],'bytes':info['TotalSize']})
 return rows

def copy_file_exclusive(source,mount,run,expected):
 # Never overwrite an existing update file. Only our temporary file is renamed.
 import ctypes
 mount=Path(mount);target=mount/'BODYDATA.DAT';partial=mount/('.a7rv-'+run+'.partial')
 if target.exists()or target.is_symlink():raise FileExistsError('卡上已有BODYDATA.DAT，未覆盖；请先自行保留旧文件后再选择此卡')
 if sha(source)!=expected:raise ValueError('源文件摘要不符')
 total=0;fd=os.open(partial,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
 with regular(source).open('rb')as src,os.fdopen(fd,'wb')as dst:
  while chunk:=src.read(8*1024*1024):
   if dst.write(chunk)!=len(chunk):raise IOError('卡上短写')
   total+=len(chunk)
   if total%(64*1024*1024)==0:note('已复制 '+str(total//1048576)+' MiB')
  dst.flush();os.fsync(dst.fileno())
  if hasattr(fcntl,'F_FULLFSYNC'):fcntl.fcntl(dst,fcntl.F_FULLFSYNC)
 if partial.stat().st_size!=regular(source).stat().st_size or sha(partial)!=expected:raise ValueError('卡上临时文件核验失败，保留现场；不要更新')
 fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);identity=os.fstat(fd)
 try:
  now=target.lstat()
  if now.st_ino!=identity.st_ino or now.st_size!=0:raise ValueError('目标保留文件发生变化')
  os.replace(partial,target)
 finally:os.close(fd)
 fd=os.open(mount,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
 try:os.fsync(fd)
 finally:os.close(fd)
 if sha(target)!=expected or sha(source)!=expected:raise ValueError('最终文件核验不符，不要更新')
 return target,total

def copy_card(request,job):
 from a7r5dat import tool
 source=regular(request['source']);receipt=load(source.with_suffix(source.suffix+'.json'))
 if receipt.get('source',{}).get('sha256')!=OFFICIAL or receipt.get('independent_decryption_exact')is not True or sha(source)!=receipt.get('sha256'):raise ValueError('请选择本工具生成且带完整回执的研究DAT')
 checked=tool.inspect(source,ENGINE/'keys/research-public.pem',full=True)
 if checked['header']['model']!='0x11030080':raise ValueError('不是本机型更新包')
 choices=[v for v in card_volumes()if v['uuid']==request['volume_uuid']]
 if len(choices)!=1:raise ValueError('升级卡已变化或不能唯一确定')
 card=choices[0];mount=Path(card['mount'])
 if mount.is_symlink()or not mount.is_relative_to('/Volumes'):raise ValueError('卡挂载路径异常')
 target,total=copy_file_exclusive(source,mount,job.name,checked['sha256'])
 result={'copy_verified':True,'source':str(source),'target':str(target),'bytes':total,'sha256':checked['sha256'],'card':card,'camera_update_started':False,'version':checked['version']}
 save(job/'card-verified.json',result)
 ejected=subprocess.run(['/usr/sbin/diskutil','eject',card['whole_disk']],capture_output=True,text=True,timeout=30)
 result.update(ejected=ejected.returncode==0,eject_message=ejected.stdout+ejected.stderr)
 return result


def verify_resources(expected):
 if not re.fullmatch('[a-f0-9]{64}',expected):raise ValueError('清单摘要无效')
 directory=ROOT.parent;m=directory/'resources.json'
 if sha(m)!=expected:raise ValueError('应用材料清单变化')
 for name,digest in load(m).items():
  p=Path(name)
  if p.is_absolute()or '..'in p.parts or sha(directory/p)!=digest:raise ValueError('应用资源变化')

def main():
 args=sys.argv[1:]
 if len(args)==3 and args[0]=='--execute':
  verify_resources(args[2]);return execute_device(run_id(args[1]))
 if len(args)!=2 or args[0]!='--request':raise ValueError('入口参数无效')
 ensure_data();identifier=run_id(args[1]);request=load(DATA/'requests'/(identifier+'.json'));action=request.pop('action')
 if action=='overview':print(json.dumps(overview(),ensure_ascii=False));return 0
 job=DATA/'jobs'/identifier;job.mkdir(mode=0o700);save(job/'request.json',{'action':action,**request})
 try:result=dispatch(action,request,job);save(job/'result.json',{'success':True,'action':action,'value':result})
 except BaseException as exc:
  result={'success':False,'action':action,'error':str(exc)};save(job/'result.json',result);print(json.dumps(result,ensure_ascii=False),flush=True);return 1
 print(json.dumps({'success':True,'action':action,'id':identifier,'value':result},ensure_ascii=False),flush=True);return 0
if __name__=='__main__':
 try:raise SystemExit(main())
 except Exception as exc:print(json.dumps({'success':False,'error':str(exc)},ensure_ascii=False),flush=True);raise SystemExit(1)
