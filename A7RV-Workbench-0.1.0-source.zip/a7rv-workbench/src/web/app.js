'use strict';
const $=id=>document.getElementById(id);const titles={home:'工作台',setup:'首装助手',firmware:'固件工坊',card:'升级卡',history:'操作记录',about:'使用说明'};let busy=false,logText='',cards=[],latestJobs=[];
const send=(command,input={})=>window.webkit.messageHandlers.native.postMessage({command,input});
function page(name){document.querySelectorAll('.page').forEach(e=>e.hidden=e.id!==name);document.querySelectorAll('nav button').forEach(e=>e.classList.toggle('active',e.dataset.page===name));$('breadcrumb').textContent='本机工具 / '+titles[name];window.scrollTo(0,0);if(name==='history')send('overview');}
document.querySelectorAll('[data-page]').forEach(e=>e.onclick=()=>page(e.dataset.page));document.querySelectorAll('[data-go]').forEach(e=>e.onclick=()=>page(e.dataset.go));
document.querySelectorAll('[data-choose]').forEach(e=>e.onclick=()=>send('choose',{kind:e.dataset.choose}));
function message(text,isError=false){$('banner').hidden=!text;$('banner').textContent=text;}
function activity(text){$('activity').hidden=false;document.body.classList.add('has-activity');$('activityTitle').textContent=text;}
function result(id,text,error=false){$(id).textContent=text;$(id).classList.toggle('error',error);}
function operate(action,input={}){if(busy){message('请先完成当前任务。');return;}logText='';$('log').textContent='';message('');send(action,input);}
$('scan').onclick=()=>operate('scan');$('capture').onclick=()=>operate('prepare_capture');$('inspectBackup').onclick=()=>{if(!$('backupPath').value)return message('请先选择完整备份。');operate('inspect_backup',{backup:$('backupPath').value});};
$('trust').onclick=()=>operate('prepare_trust',{backup:$('backupPath').value});$('inspectFirmware').onclick=()=>{if(!$('sourcePath').value)return message('请先选择官方原包。');operate('inspect_firmware',{source:$('sourcePath').value});};
$('build').onclick=()=>{if(!$('sourcePath').value||!$('outputPath').value)return message('请先选择官方原包和新的输出位置。');const features={};['fl23','looks','ntsc','sound'].forEach(k=>features[k]=$(k).checked);operate('firmware',{source:$('sourcePath').value,output:$('outputPath').value,features,version:'4.06'});};
$('listCards').onclick=()=>operate('card_volumes');$('copyCard').onclick=()=>{if(!$('cardSource').value||!$('volumes').value)return message('请选择已生成的研究包和目标升级卡。');operate('copy_card',{source:$('cardSource').value,volume_uuid:$('volumes').value});};
$('refresh').onclick=()=>send('overview');$('openData').onclick=$('openAbout').onclick=()=>send('reveal');
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function jobs(rows){latestJobs=rows;$('jobs').innerHTML=rows.length?'':'<div class="notice">还没有操作记录。可从首装助手或固件工坊开始。</div>';rows.forEach(row=>{
 const req=row['request.json']||{},a=req.action||'',r=row['result.json']||{},d=row['device-result.json'];const labels={scan:'连接检查',inspect_firmware:'官方原包核查',inspect_backup:'备份兼容性检查',firmware:'研究固件封包',prepare_capture:'原厂一号分区备份',prepare_trust:'更新器信任修改',card_volumes:'外接卡检查',copy_card:'升级卡准备',confirm_screen:'屏幕确认'};
 let status=d?(d.complete?'已完成，待核对屏幕':'未完整完成，保留现场'):r.success===false?'失败，查看记录':r.value?.state==='awaiting-terminal'?'等待终端结果':r.success?'已完成':'处理中';if(!d&&row['terminal-result.json'])status='终端已结束，查看本次日志';if(row['screen-confirmation.json'])status='已完成，屏幕已确认';
 const card=document.createElement('article');card.className='task';card.innerHTML='<div class="task-top"><h3>'+esc(labels[a]||'任务')+'</h3><span class="badge '+((d&&!d.complete)||r.success===false?'failed':'')+'">'+esc(status)+'</span></div><p>'+esc(row.id)+'</p>';
 if(d){const p=document.createElement('p');p.textContent=d.complete?'完整验证及海量存储恢复通过，请确认相机屏幕。':'任务结果不完整。可能已上传程序或开始分区写入，不要直接重跑。';card.appendChild(p);}
 if(r.error||d?.failure){const p=document.createElement('p');p.textContent=r.error||d.failure;card.appendChild(p);}
 const open=document.createElement('button');open.textContent='打开本次记录';open.onclick=()=>send('reveal',{id:row.id});card.appendChild(open);
 if(d?.complete&&!row['screen-confirmation.json']){const confirm=document.createElement('button');confirm.textContent='相机屏幕已恢复海量存储';confirm.onclick=()=>operate('confirm_screen',{job_id:row.id});card.appendChild(confirm);}
 if(d?.complete&&d.kind==='capture'){const use=document.createElement('button');use.textContent='使用这份备份检查兼容性';use.onclick=()=>{$('backupPath').value=row.directory+'/device/partition1.logical.bin';page('setup');operate('inspect_backup',{backup:$('backupPath').value});};card.appendChild(use);}
 if(a==='firmware'&&r.success){const use=document.createElement('button');use.textContent='准备此包的升级卡';use.onclick=()=>{$('cardSource').value=r.value.output;page('card');};card.appendChild(use);}
 $('jobs').appendChild(card);
 });}
window.onNative=event=>{
 if(event.type==='picked'){const map={firmware:'sourcePath',backup:'backupPath',output:'outputPath',package:'cardSource'};$(map[event.kind]).value=event.path;if(event.kind==='backup'){$('trust').disabled=true;$('trust').textContent='先核对受支持的原始备份';}return;}
 if(event.type==='cancelled'){busy=false;$('activity').hidden=true;document.body.classList.remove('has-activity');message('已取消本次准备，未开始设备操作。');return;}
 if(event.type==='error'){busy=false;message(event.message,true);$('activityTitle').textContent='操作未完成';return;}
 if(event.type==='started'){if(event.action!=='overview'){busy=true;activity(({scan:'检查连接',inspect_backup:'核对完整备份',inspect_firmware:'核对官方原包',firmware:'验证并生成固件',prepare_capture:'准备本次备份',prepare_trust:'准备本次信任修改',card_volumes:'识别升级卡',copy_card:'复制并核对升级卡'})[event.action]||'处理任务');$('activityMessage').textContent='可在操作记录中查看结果';}return;}
 if(event.type==='log'){logText+=event.text;$('log').textContent=logText.slice(-30000);for(const line of event.text.split('\n')){try{const v=JSON.parse(line);if(v.progress)$('activityMessage').textContent=v.progress;}catch{}}return;}
 if(event.type==='terminalFinished'){busy=false;activity('本次终端流程已结束');$('activityMessage').textContent='请核对任务结果与相机屏幕';page('history');return;}
 if(event.type==='finished'){
  const action=event.action;const outer=event.value||{};const v=outer.value||outer;if(action==='overview'){jobs(v.jobs||[]);return;}
  busy=false;if(event.exit_code!==0||outer.success===false){message(outer.error||'操作未完成，请在记录中查看错误；设备动作不要直接重试。',true);$('activityTitle').textContent='已停止，结果保留';send('overview');return;}
  $('activityTitle').textContent=({scan:'连接检查完成',inspect_backup:'备份检查完成',inspect_firmware:'官方原包核查完成',firmware:'离线固件封包完成',card_volumes:'外接卡检查完成',copy_card:'升级卡核对完成',confirm_screen:'屏幕确认已保存'})[action]||'本次电脑端步骤完成';$('activityMessage').textContent='结果已保存';
  if(action==='scan')result('scanResult','已识别 '+v.baseline.observed_product+'，海量存储身份与媒体信息稳定。');
  if(action==='inspect_firmware')result('firmwareResult','指定官方 4.00 原包摘要、外层签名和版本头通过；封包时将解密并核对全部帧。');
  if(action==='inspect_backup'){
   const good=v.state==='supported-original';$('trust').disabled=!good;$('trust').textContent=good?'准备本次258扇区信任修改':'当前备份不能执行首装写入';
   result('backupResult',good?('完整原像匹配：'+(v.live_verified_layout?'本机曾实测的布局。其他机身仍需逐台验收。':'参考布局，仅有离线验证；机内执行尚未验证。')):v.state==='already-trusted'?'与已知信任候选一致，无需重复写入。':'该原像尚未适配。保留备份，停止写入。',!good&&v.state!=='already-trusted');
  }
  if(action==='firmware'){$('cardSource').value=v.output;result('buildResult','已生成并通过签名、独立解密回读：'+v.output+'。尚未写卡或安装。');}
  if(action==='card_volumes'){cards=v.volumes||[];$('volumes').replaceChildren();const first=document.createElement('option');first.value='';first.textContent=cards.length?'请选择目标卡':'未发现可写且空间充足的外接卡';$('volumes').appendChild(first);cards.forEach(c=>{const e=document.createElement('option');e.value=c.uuid;e.textContent=c.name+' · '+(c.bytes/2**30).toFixed(1)+' GiB · 可用 '+(c.free_bytes/2**30).toFixed(1)+' GiB';$('volumes').appendChild(e);});}
  if(action==='copy_card')result('cardResult',v.ejected?'卡上完整摘要一致，升级卡已推出。若相机还有PMHOME等卷，请先一起安全推出，再断开USB。尚未启动机身更新。':'文件核验通过，但安全推出未完成。请先在Finder安全推出，不要直接拔线。');
  if(action.startsWith('prepare_')){busy=true;activity('请在终端完成本次授权');$('activityMessage').textContent='Mac密码只输入终端，不输入应用';message('终端已打开。授权后保持相机供电及USB连接，等待固定结果返回。');}
  if(action==='confirm_screen')message('屏幕确认已保存。');send('overview');
 }
};
send('overview');
