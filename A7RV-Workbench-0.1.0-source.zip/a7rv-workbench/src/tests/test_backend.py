from pathlib import Path
import importlib.util,json,hashlib,os,shutil,sys
import pytest
D=Path(__file__).resolve().parents[1]
E=Path(os.environ['A7RV_ENGINE']).resolve()
ORIGINAL=Path(os.environ['A7RV_STOCK_IMAGE']).resolve() if os.environ.get('A7RV_STOCK_IMAGE') else None
def original_fixture():
 if ORIGINAL is None:pytest.skip('Optional private stock image: set A7RV_STOCK_IMAGE locally')
 return ORIGINAL
sys.path[:0]=[str(D),str(E),str(E/'site')]
import backend as b
b.ENGINE=E;b.ASSETS=D.parent/'build-assets'
@pytest.fixture(autouse=True)
def isolated(tmp_path,monkeypatch):
 monkeypatch.setattr(b,'DATA',tmp_path/'data');b.ensure_data()
 def forbidden(*a,**k):raise AssertionError('No hardware/process in unit tests')
 monkeypatch.setattr(b.subprocess,'run',forbidden)
 yield
 if tmp_path.is_dir()and not tmp_path.is_symlink():shutil.rmtree(tmp_path)

@pytest.mark.parametrize('name',['capture.so','cleanup.so','stock-v1.so','reference-v1.so'])
def test_exact_run_rendering(name):
 raw=(b.ASSETS/name).read_bytes();new=b.render(name,'f'*32)
 assert len(raw)==len(new)and b.MARKER.encode()not in new
 assert new.replace(b'f'*32,b.MARKER.encode())==raw
 assert raw[:4]==b'\x7fELF'and int.from_bytes(raw[18:20],'little')==183

@pytest.mark.parametrize('run',['','x'*32,'../','a'*31,'f'*33])
def test_bad_run_refused(run):
 with pytest.raises(ValueError):b.render('capture.so',run)


def test_overview_never_queries_camera():
 result=b.overview();assert not result['camera_queried']and result['jobs']==[]

@pytest.mark.parametrize('kind',['short','unknown','symlink'])
def test_invalid_backup_never_supported(tmp_path,kind):
 p=tmp_path/'input'
 if kind=='symlink':p.symlink_to('/dev/null')
 elif kind=='short':p.write_bytes(b'a')
 else:
  with p.open('wb')as f:f.truncate(b.SIZE)
 if kind=='unknown':assert b.identify_backup(p)['state']=='unsupported'
 else:
  with pytest.raises(ValueError):b.identify_backup(p)


def test_source_bound_candidate_and_inverse():
 p=original_fixture()
 info=b.identify_backup(p);assert info['profile']=='stock-v1'
 raw=p.read_bytes();new,plan=b.candidate_bytes(raw,'stock-v1')
 assert hashlib.sha256(new).hexdigest()==b.profiles()['stock-v1']['target_sha256']
 assert len(plan['rows'])==258 and sum(a!=c for a,c in zip(raw,new))==128485
 inverse=bytearray(new)
 for row in b.profiles()['stock-v1']['rows']:
  at=row['offset'];inverse[at:at+512]=__import__('base64').b64decode(row['before'])
 assert inverse==raw
 with pytest.raises(ValueError):b.candidate_bytes(new,'stock-v1')


def test_unrecognized_image_not_patched():
 with pytest.raises(ValueError):b.candidate_bytes(bytes(b.SIZE),'stock-v1')


def test_already_trusted_refuses_install(tmp_path):
 p=tmp_path/'trusted.bin';raw,_=b.candidate_bytes(original_fixture().read_bytes(),'stock-v1');p.write_bytes(raw)
 assert b.identify_backup(p)['state']=='already-trusted'

@pytest.mark.parametrize('action',['prepare_capture','prepare_trust','copy_card'])
def test_device_or_card_action_requires_native_confirmation(tmp_path,action):
 with pytest.raises(ValueError,match='确认'):b.dispatch(action,{},tmp_path)


def test_unknown_action_refused(tmp_path):
 with pytest.raises(ValueError):b.dispatch('execute_shell',{},tmp_path)


def test_unresolved_previous_attempt_blocks_new_transaction(tmp_path):
 old=b.DATA/'jobs'/('1'*32);old.mkdir();(old/'device.attempt').write_text('{}')
 new=b.DATA/'jobs'/('2'*32);new.mkdir()
 with pytest.raises(ValueError,match='上一设备任务'):b.prepare_device(new,'capture',{})


def test_regular_rejects_links_and_devices(tmp_path):
 p=tmp_path/'link';p.symlink_to('/etc/hosts')
 with pytest.raises(ValueError):b.regular(p)
 with pytest.raises(ValueError):b.regular('/dev/null')


def test_existing_card_update_file_never_overwritten(tmp_path):
 source=tmp_path/'source';source.write_bytes(b'payload');card=tmp_path/'card';card.mkdir();target=card/'BODYDATA.DAT';target.write_bytes(b'original')
 with pytest.raises(FileExistsError):b.copy_file_exclusive(source,card,'a'*32,b.sha(source))
 assert target.read_bytes()==b'original'


def test_card_copy_exact_and_no_partial_left(tmp_path,monkeypatch):
 source=tmp_path/'source';source.write_bytes(os.urandom(1024*1024+3));card=tmp_path/'card';card.mkdir();keep=card/'photo';keep.write_bytes(b'keep')
 # Ordinary-file fixture cannot emulate physical-drive cache flushing.
 if hasattr(b.fcntl,'F_FULLFSYNC'):monkeypatch.delattr(b.fcntl,'F_FULLFSYNC')
 target,count=b.copy_file_exclusive(source,card,'b'*32,b.sha(source))
 assert target.read_bytes()==source.read_bytes()and count==source.stat().st_size and keep.read_bytes()==b'keep'
 assert sorted(p.name for p in card.iterdir())==['BODYDATA.DAT','photo']


def test_capture_package_and_operation_binding(tmp_path,monkeypatch):
 cfg=json.loads((E/'profile.json').read_text());baseline={'kind':'ordinary','location_id':17825792,'pid':3594,'media':[[True,256060514304]],'drivers':['IOUSBMassStorageDriver'],'model':'ILCE-7RM5','observed_product':'ILCE-7RM5'}
 monkeypatch.setattr(b,'baseline',lambda job:baseline)
 job=b.DATA/'jobs'/('c'*32);job.mkdir();b.setup_package(job,'capture')
 assert b.validate_device_materials(job/'package','capture')
 op=b.operation(job/'package','capture');assert op.run==job.name and not op.safe_to_stop and op.packet_limit==4096
 cfg=b.load(job/'package/config.json');cfg['metadata_policy']='skip';(job/'package/config.json').write_text(json.dumps(cfg))
 with pytest.raises(ValueError):b.validate_device_materials(job/'package','capture')


def test_trust_package_bound_to_this_image_and_run(tmp_path,monkeypatch):
 baseline={'kind':'ordinary','location_id':17825792,'pid':3594,'media':[[True,256060514304]],'drivers':['IOUSBMassStorageDriver'],'model':'ILCE-7RM5','observed_product':'ILCE-7RM5'}
 monkeypatch.setattr(b,'baseline',lambda job:baseline)
 job=b.DATA/'jobs'/('d'*32);job.mkdir();b.setup_package(job,'trust',original_fixture())
 assert b.validate_device_materials(job/'package','trust')
 op=b.operation(job/'package','trust');assert op.run==job.name and not op.safe_to_stop and len(op.parts)==1532
 p=job/'package/materials/libJit.so';raw=bytearray(p.read_bytes());raw[-1]^=1;p.write_bytes(raw)
 with pytest.raises(ValueError):b.validate_device_materials(job/'package','trust')


def test_privileged_helper_requires_administrator_before_runtime():
 with pytest.raises(ValueError):b.execute_device('e'*32)


def test_firmware_receipt_is_separate_from_task_receipt(tmp_path,monkeypatch):
 import firmware
 monkeypatch.setattr(b.shutil,'disk_usage',lambda path:type('Free',(),{'free':6<<30})())
 def build(request,job):
  assert job==tmp_path/'firmware'
  b.save(job/'result.json',{'inner_receipt':True})
  guide=tmp_path/'test-guide.html';guide.write_text('<html><head></head><body>指南</body></html>')
  return {'guide':str(guide),'output':'fixture.DAT'}
 monkeypatch.setattr(firmware,'build',build)
 value=b.dispatch('firmware',{'features':{'fl23':True,'looks':True,'ntsc':True,'sound':True},'output':str(tmp_path/'fixture.DAT')},tmp_path)
 b.save(tmp_path/'result.json',{'success':True,'value':value})
 assert b.load(tmp_path/'result.json')['success']is True
 assert b.load(tmp_path/'firmware/result.json')['inner_receipt']is True
 assert 'SimSun'in(tmp_path/'test-guide.html').read_text()


def test_firmware_requires_real_free_space_before_unpack(tmp_path,monkeypatch):
 monkeypatch.setattr(b.shutil,'disk_usage',lambda path:type('Free',(),{'free':4<<30})())
 with pytest.raises(ValueError,match='4GiB'):b.dispatch('firmware',{'features':{'fl23':True,'looks':False,'ntsc':False,'sound':False},'output':str(tmp_path/'fixture.DAT')},tmp_path)
 assert not(tmp_path/'firmware').exists()
