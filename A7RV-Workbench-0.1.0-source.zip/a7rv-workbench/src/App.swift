import AppKit
import WebKit
import CryptoKit

let resourceSeal = "__RESOURCE_SEAL__"
final class AppDelegate: NSObject, NSApplicationDelegate, WKScriptMessageHandler, WKNavigationDelegate, NSWindowDelegate {
 var window:NSWindow!; var web:WKWebView!; var busy=false; var deviceJob:String?; var timer:Timer?
 let fm=FileManager.default
 var resources:URL { Bundle.main.resourceURL! }
 var appRoot:URL { resources.appendingPathComponent("app") }
 var data:URL { fm.homeDirectoryForCurrentUser.appendingPathComponent("Library/Application Support/local.a7rv.workbench") }
 func digest(_ url:URL)throws->String { let handle=try FileHandle(forReadingFrom:url);defer{try? handle.close()};var h=SHA256();while let b=try handle.read(upToCount:1048576), !b.isEmpty{h.update(data:b)};return h.finalize().map{String(format:"%02x",$0)}.joined() }
 func verify()throws {
  let m=resources.appendingPathComponent("resources.json")
  guard try digest(m)==resourceSeal else{throw NSError(domain:"材料清单变化，请重新安装应用",code:1)}
  let rows=try JSONSerialization.jsonObject(with:Data(contentsOf:m))as! [String:String]
  for (name,h) in rows {
   guard !name.hasPrefix("/"), !name.split(separator:"/").contains("..") else{throw NSError(domain:"材料路径异常",code:1)}
   let u=resources.appendingPathComponent(name);let values=try u.resourceValues(forKeys:[.isSymbolicLinkKey])
   guard values.isSymbolicLink != true,try digest(u)==h else{throw NSError(domain:"应用材料变化："+name,code:1)}
  }
 }
 func applicationDidFinishLaunching(_ notification:Notification) {
  do{try verify();try fm.createDirectory(at:data.appendingPathComponent("requests"),withIntermediateDirectories:true,attributes:[.posixPermissions:0o700])}catch{NSAlert(error:error).runModal();NSApp.terminate(nil);return}
  let config=WKWebViewConfiguration();config.userContentController.add(self,name:"native");config.preferences.javaScriptCanOpenWindowsAutomatically=false
  web=WKWebView(frame:.zero,configuration:config);web.navigationDelegate=self
  window=NSWindow(contentRect:NSRect(x:0,y:0,width:1180,height:820),styleMask:[.titled,.closable,.miniaturizable,.resizable],backing:.buffered,defer:false)
  window.title="A7R V 工坊 · 研究测试版";window.minSize=NSSize(width:980,height:720);window.delegate=self;window.contentView=web;window.center();window.makeKeyAndOrderFront(nil)
  web.loadFileURL(appRoot.appendingPathComponent("web/index.html"),allowingReadAccessTo:appRoot.appendingPathComponent("web"));NSApp.activate(ignoringOtherApps:true)
 }
 func applicationShouldTerminate(_ sender:NSApplication)->NSApplication.TerminateReply{if busy{show("任务尚未结束","请等待固定结果返回，不要中断未知状态的机内任务。");return .terminateCancel};return .terminateNow}
 func applicationShouldTerminateAfterLastWindowClosed(_ sender:NSApplication)->Bool{!busy}
 func windowShouldClose(_ sender:NSWindow)->Bool{if busy{show("任务仍在进行","请等待结果返回。机内操作状态未知时不要关闭应用或重复执行。");return false};return true}
 func show(_ title:String,_ text:String){let a=NSAlert();a.messageText=title;a.informativeText=text;a.runModal()}
 func send(_ value:[String:Any]){guard let b=try? JSONSerialization.data(withJSONObject:value),let s=String(data:b,encoding:.utf8)else{return};web.evaluateJavaScript("window.onNative(\(s))",completionHandler:nil)}
 func picked(_ kind:String)->String?{
  if kind=="output"{let p=NSSavePanel();p.title="保存研究更新包";p.nameFieldStringValue="BODYDATA-custom.DAT";return p.runModal() == .OK ? p.url?.path:nil}
  let p=NSOpenPanel();p.canChooseFiles=true;p.canChooseDirectories=false;p.allowsMultipleSelection=false;p.title=kind=="firmware" ? "选择指定官方4.00 BODYDATA.DAT":kind=="package" ? "选择生成的研究DAT":"选择完整一号分区备份 partition1.logical.bin"
  return p.runModal() == .OK ? p.url?.path:nil
 }
 func quote(_ s:String)->String{"'"+s.replacingOccurrences(of:"'",with:"'\\''")+"'"}
 func terminal(_ id:String)throws{
  let job=data.appendingPathComponent("jobs/"+id);let entry=appRoot.appendingPathComponent("backend.py");let python=resources.appendingPathComponent("engine/python/bin/python3.14");let entrySHA=try digest(entry)
  let command="""
#!/bin/zsh
set -u
set -o pipefail
umask 077
actual=$(/usr/bin/shasum -a 256 \(quote(entry.path)))
actual=${actual%% *}
if [[ "$actual" != \(quote(entrySHA)) ]]; then
 print '入口校验不符，未执行。'
 exit 1
fi
/usr/bin/sudo -- \(quote(python.path)) -I -S -B \(quote(entry.path)) --execute \(quote(id)) \(quote(resourceSeal)) 2>&1 | /usr/bin/tee -a \(quote(job.appendingPathComponent("terminal.log").path))
code=${pipestatus[1]}
print "{\\\"exit_code\\\":$code}" > \(quote(job.appendingPathComponent("terminal-result.new").path))
/bin/mv -n \(quote(job.appendingPathComponent("terminal-result.new").path)) \(quote(job.appendingPathComponent("terminal-result.json").path))
print '本次流程结束，请回到工坊查看结果。不要重复运行此入口。'
exit $code
"""
  let script=job.appendingPathComponent("本次授权.command");try command.write(to:script,atomically:true,encoding:.utf8);try fm.setAttributes([.posixPermissions:0o700],ofItemAtPath:script.path)
  deviceJob=id;busy=true
  let open=Process();open.executableURL=URL(fileURLWithPath:"/usr/bin/open");open.arguments=["-a","Terminal",script.path];try open.run()
  timer=Timer.scheduledTimer(withTimeInterval:1,repeats:true){[weak self] _ in
   guard let self=self else{return}
   if self.fm.fileExists(atPath:job.appendingPathComponent("terminal-result.json").path){self.timer?.invalidate();self.busy=false;self.deviceJob=nil;self.send(["type":"terminalFinished","id":id]);self.launch("overview",[:],allowBusy:true)}
  }
 }
 func launch(_ action:String,_ input:[String:Any],allowBusy:Bool=false){
  if busy && !allowBusy{send(["type":"error","message":"请先完成当前任务"]);return}
  do{
   try verify();let id=UUID().uuidString.replacingOccurrences(of:"-",with:"").lowercased();var request=input;request["action"]=action
   let path=data.appendingPathComponent("requests/"+id+".json");try JSONSerialization.data(withJSONObject:request).write(to:path,options:.withoutOverwriting);try fm.setAttributes([.posixPermissions:0o600],ofItemAtPath:path.path)
   if action != "overview"{busy=true};send(["type":"started","id":id,"action":action])
   let p=Process();p.executableURL=resources.appendingPathComponent("engine/python/bin/python3.14");p.arguments=["-I","-S","-B",appRoot.appendingPathComponent("backend.py").path,"--request",id];p.environment=["HOME":fm.homeDirectoryForCurrentUser.path,"PATH":"/usr/bin:/bin:/usr/sbin:/sbin","TMPDIR":NSTemporaryDirectory(),"PYTHONDONTWRITEBYTECODE":"1"]
   let pipe=Pipe();p.standardOutput=pipe;p.standardError=pipe;var all=Data()
   pipe.fileHandleForReading.readabilityHandler={ [weak self] h in let b=h.availableData;if !b.isEmpty{DispatchQueue.main.async{all.append(b);self?.send(["type":"log","id":id,"text":String(decoding:b,as:UTF8.self)])}} }
   p.terminationHandler={ [weak self] done in DispatchQueue.main.async{guard let self=self else{return};pipe.fileHandleForReading.readabilityHandler=nil
    let tail=pipe.fileHandleForReading.readDataToEndOfFile();all.append(tail);if !tail.isEmpty{self.send(["type":"log","id":id,"text":String(decoding:tail,as:UTF8.self)])}
    if action != "overview" {self.busy=false}
    let lines=String(decoding:all,as:UTF8.self).split(separator:"\n");let value=lines.reversed().compactMap{try? JSONSerialization.jsonObject(with:Data($0.utf8))as? [String:Any]}.first ?? [:]
    self.send(["type":"finished","action":action,"id":id,"exit_code":done.terminationStatus,"value":value])
    if done.terminationStatus==0,action.hasPrefix("prepare_"){do{try self.terminal(id)}catch{self.busy=false;self.send(["type":"error","message":error.localizedDescription])}}
   }}
   try p.run()
  }catch{busy=false;send(["type":"error","message":error.localizedDescription])}
 }
 func userContentController(_ userContentController:WKUserContentController,didReceive message:WKScriptMessage){
  guard message.frameInfo.isMainFrame,let body=message.body as? [String:Any],let cmd=body["command"]as? String else{return}
  let input=body["input"]as? [String:Any] ?? [:]
  if cmd=="choose"{if let kind=input["kind"]as? String,let path=picked(kind){send(["type":"picked","kind":kind,"path":path])};return}
  if cmd=="reveal"{if let id=input["id"]as? String,id.range(of:"^[a-f0-9]{32}$",options:.regularExpression) != nil{NSWorkspace.shared.open(data.appendingPathComponent("jobs/"+id))}else{NSWorkspace.shared.open(data)};return}
  let allowed:Set<String>=["overview","scan","inspect_firmware","inspect_backup","firmware","prepare_capture","prepare_trust","confirm_screen","card_volumes","copy_card"]
  guard allowed.contains(cmd)else{return}
  var values=input
  if ["prepare_capture","prepare_trust","copy_card"].contains(cmd){
   if busy{send(["type":"error","message":"当前任务还未结束"]);return}
   let alert=NSAlert();alert.messageText=cmd=="prepare_capture" ? "执行本次一号分区备份？":cmd=="prepare_trust" ? "执行本次258扇区信任修改？":"复制研究固件到所选升级卡？"
   alert.informativeText=cmd=="prepare_capture" ? "会上传并执行机内程序，只读分区并在电脑完整核验后清理本次RAM副本。固定临时路径可能覆盖不可读文件，服务可能失效。此备份不是全机备份，也不是已验证救援。仅适配预加载文件缺失的原厂4.00；其他状态停止。":cmd=="prepare_trust" ? "这会永久改变更新器信任策略，最多写入258扇区并完整回读。断电、短写或失败可能使相机不能启动，目前没有已验证救援。参考布局仅离线验证。任务不自动回滚、重试或安装固件；失败后保留现场。":"会将已核验研究包复制为升级卡根目录BODYDATA.DAT，不格式化、不覆盖已有同名文件。复制完成不会启动相机升级；卡刷需在机身上单独决定。"
   alert.addButton(withTitle:"确认本次操作");alert.addButton(withTitle:"取消")
   guard alert.runModal() == .alertFirstButtonReturn else{send(["type":"cancelled","action":cmd]);return};values["native_confirmed"]=true
  }
  launch(cmd,values,allowBusy:cmd=="overview")
 }
 func webView(_ webView:WKWebView,decidePolicyFor action:WKNavigationAction,decisionHandler:@escaping(WKNavigationActionPolicy)->Void){guard let u=action.request.url else{decisionHandler(.cancel);return};decisionHandler((u.isFileURL && u.path.hasPrefix(appRoot.appendingPathComponent("web").path))||u.absoluteString=="about:blank" ? .allow:.cancel)}
}
if CommandLine.arguments==[CommandLine.arguments[0],"--selfcheck"] {
 do{try AppDelegate().verify();print("{\"resources_verified\":true,\"camera_access\":false,\"version\":\"0.1.0\"}");exit(0)}catch{fputs((error.localizedDescription+"\n"),stderr);exit(1)}
}
let app=NSApplication.shared
let delegate=AppDelegate();app.delegate=delegate;app.setActivationPolicy(.regular);app.run()
